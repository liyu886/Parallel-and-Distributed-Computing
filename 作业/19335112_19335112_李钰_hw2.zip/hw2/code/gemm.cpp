#include<iostream>
#include<stdlib.h>
#include<time.h>
#include<vector>
#include<fstream>
#include"timer.h"

#define range 100
using namespace std;

void gemm(vector<vector<int> >&matrix_ans, vector<vector<int> >matrixA,vector<vector<int> > matrixB);

int main(){
    int n = 512;
    double start, finish;
    ofstream fp;
    fp.open("result.txt");



    int seed = time(0);
    srand(seed);

    vector<vector<int> > matrixA(n, vector<int>(n, 0));
    vector<vector<int> > matrixB(n, vector<int>(n, 0));
    vector<vector<int> > matrix_ans(n, vector<int>(n, 0));

    
    for(int i = 0; i < n; i++){
        for(int j = 0; j < n; j++){
            matrixA[i][j] = rand() % range;
            matrixB[i][j] = rand() % range;
        }
    }

    //cout << "random " << m << "*" << n << " matrix " << endl;
    fp << "random " << n << "*" << n << " matrix " << endl;

    for(int i = 0; i < n; i++){
        for(int j = 0; j < n; j++){
            //cout << matrixA[i][j] << " ";
            fp << matrixA[i][j] << " ";
        }
        //cout << endl;
        fp << endl;
    }
    
    //cout << "random " << n << "*" << k << " matrix " << endl;
    fp << "random " << n << "*" << n << " matrix " << endl;

    for(int i = 0; i < n; i++){
        for(int j = 0; j < n; j++){
            //cout << matrixB[i][j] << " ";
            fp << matrixB[i][j] << " ";
        }
        //cout << endl;
        fp << endl;
    }

    GET_TIME(start)
    gemm(matrix_ans, matrixA, matrixB);
    GET_TIME(finish);
    fp << "result2" << endl;
    
    for(int i = 0; i < n; i++){
        for(int j = 0; j < n; j++){
            //cout << matrix_ans[i][j] << " ";
            fp << matrix_ans[i][j] << " ";
        }
        //cout << endl;
        fp << endl;
    }
    fp.close();
    cout << "gmee: " << endl;
    cout << n << " * " << n << " matrixA times " << n << " * " << n << " matrixB " << endl;
    cout << "Runtime is " << finish - start << endl;

    
   
    

}


void print(vector<vector<int> > n){
    for(int i = 0; i < n.size(); i++){
        for(int j = 0; j < n[i].size(); j++){
            cout << n[i][j] << " ";
        }
        cout << endl;
    }
}

void gemm(vector<vector<int> >&matrix_ans, vector<vector<int> >matrixA,vector<vector<int> > matrixB){
    int n = matrix_ans.size();
    for(int i = 0; i < n; i++){
        for(int j = 0; j < n; j++){
            for(int a = 0; a < n; a++){
                matrix_ans[i][j] += matrixA[i][a] * matrixB[a][j];
            }
        }
    }
}

