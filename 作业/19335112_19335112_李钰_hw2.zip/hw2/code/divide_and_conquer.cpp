#include<iostream>
#include<stdlib.h>
#include<time.h>
#include<vector>
#include<fstream>
#include "timer.h"
#define range 100
using namespace std;
void gemm(vector<vector<int> >&matrix_ans, vector<vector<int> >matrixA,vector<vector<int> > matrixB);

void print(vector<vector<int> > n);
//分解
void separate(vector<vector <int> >matrix, vector<vector <int> >& A11, vector<vector <int> >&A12, vector<vector <int> >&A21, vector<vector <int> >&A22);
void sum(vector<vector <int> >&sum, vector<vector <int> > a, vector<vector <int> >b);
void divide_and_conquer(vector<vector<int> > &matrix_ans, vector<vector<int> > matrixA, vector<vector<int> > matrixB);

int main(){
    int n = 512;
    double start, finish;
    ofstream fp;
    fp.open("result.txt");



    int seed = time(0);
    srand(seed);

    vector<vector<int> > matrixA(n, vector<int>(n, 0));
    vector<vector<int> > matrixB(n, vector<int>(n, 0));
    vector<vector<int> > matrix_ans(n, vector<int>(n, 0));

    
    for(int i = 0; i < n; i++){
        for(int j = 0; j < n; j++){
            matrixA[i][j] = rand() % range;
            matrixB[i][j] = rand() % range;
        }
    }


    //cout << "random " << n << "*" << n << " matrix " << endl;
    fp << "random " << n << "*" << n << " matrix " << endl;

    for(int i = 0; i < n; i++){
        for(int j = 0; j < n; j++){
            //cout << matrixA[i][j] << " ";
            fp << matrixA[i][j] << " ";
        }
        //cout << endl;
        fp << endl;
    }
    
    //cout << "random " << n << "*" << n << " matrix " << endl;
    fp << "random " << n << "*" << n << " matrix " << endl;

    for(int i = 0; i < n; i++){
        for(int j = 0; j < n; j++){
            //cout << matrixB[i][j] << " ";
            fp << matrixB[i][j] << " ";
        }
        //cout << endl;
        fp << endl;
    }
    GET_TIME(start);
    divide_and_conquer(matrix_ans, matrixA, matrixB);
    GET_TIME(finish);

    for(int i = 0; i < n; i++){
        for(int j = 0; j < n; j++){
            //cout << matrix_ans[i][j] << " ";
            fp << matrix_ans[i][j] << " ";
        }
        //cout << endl;
        fp << endl;
    }

    
    fp.close();
    cout << "divide_and_conquer: " << endl;
    cout << n << " * " << n << " matrixA times " << n << " * " << n << " matrixB " << endl;
    cout << "Runtime is " << finish - start << endl;

    //cout << "result" << endl;
   
    

}


void print(vector<vector<int> > n){
    for(int i = 0; i < n.size(); i++){
        for(int j = 0; j < n[i].size(); j++){
            cout << n[i][j] << " ";
        }
        cout << endl;
    }
}


void separate(vector<vector <int> >matrix, vector<vector <int> >& A11, vector<vector <int> >&A12, vector<vector <int> >&A21, vector<vector <int> >&A22){
    vector<int> temp1, temp2, temp3, temp4;
    int size = matrix.size();
    for(int i = 0; i < size/2; i++){
        temp1.assign(matrix[i].begin(), matrix[i].begin() + size/2);
        A11.push_back(temp1);
        //要求：A11是空的

        temp2.assign(matrix[i].begin() + size/2, matrix[i].end());
        A12.push_back(temp2);

        temp3.assign(matrix[size/2 + i].begin(), matrix[size/2 + i].begin() + size/2);
        A21.push_back(temp3);

        temp4.assign(matrix[size/2 + i].begin() + size/2, matrix[size/2 + i].end());
        A22.push_back(temp4);
    }
    
}

void sum(vector<vector <int> >&sum, vector<vector <int> > a, vector<vector <int> >b){
    for(int i = 0; i < a.size(); i++){
        for(int j = 0; j < a[i].size(); j++){
            sum[i][j] = a[i][j] + b[i][j];
        }
    }
}

void merge(vector<vector<int> > & matrix_ans, vector<vector<int> > C11, vector<vector<int> > C12, vector<vector<int> > C21, vector<vector<int> > C22){
    int n = matrix_ans.size();
    for(int i = 0; i < n; i++){
        for(int j = 0; j < n; j++){
            if(i < n/2 && j < n/2){
                matrix_ans[i][j] = C11[i][j];
            }else if(i < n/2 && j >= n/2){
                matrix_ans[i][j] = C12[i][j - n/2];
            }else if(i >= n/2 && j < n/2){
                matrix_ans[i][j] = C21[i - n/2][j];
            }else{
                matrix_ans[i][j] = C22[i - n/2][j - n/2];
            }
        }
    }
}

void divide_and_conquer(vector<vector<int> > &matrix_ans, vector<vector<int> > matrixA, vector<vector<int> > matrixB){
    if(matrixA.size() <= 64){
        gemm(matrix_ans, matrixA, matrixB);
        return ;
    }

    //分解
    vector<vector<int> > A11;
    vector<vector<int> > A12;
    vector<vector<int> > A21;
    vector<vector<int> > A22;
    vector<vector<int> > B11;
    vector<vector<int> > B12;
    vector<vector<int> > B21;
    vector<vector<int> > B22;

    separate(matrixA, A11, A12, A21, A22);
    separate(matrixB, B11, B12, B21, B22);


    //计算
    int n = A11.size();
    vector<vector<int> > temp1(n, vector<int>(n, 0));
    vector<vector<int> > temp2(n, vector<int>(n, 0));
    vector<vector<int> > temp3(n, vector<int>(n, 0));
    vector<vector<int> > temp4(n, vector<int>(n, 0));
    vector<vector<int> > temp5(n, vector<int>(n, 0));
    vector<vector<int> > temp6(n, vector<int>(n, 0));
    vector<vector<int> > temp7(n, vector<int>(n, 0));
    vector<vector<int> > temp8(n, vector<int>(n, 0));

    divide_and_conquer(temp1, A11, B11);
    divide_and_conquer(temp2, A12, B21);
    divide_and_conquer(temp3, A11, B12);
    divide_and_conquer(temp4, A12, B22);
    divide_and_conquer(temp5, A21, B11);
    divide_and_conquer(temp6, A22, B21);
    divide_and_conquer(temp7, A21, B12);
    divide_and_conquer(temp8, A22, B22);

    
    vector<vector<int> > C11(n, vector<int>(n, 0));
    vector<vector<int> > C12(n, vector<int>(n, 0));
    vector<vector<int> > C21(n, vector<int>(n, 0));
    vector<vector<int> > C22(n, vector<int>(n, 0));

    sum(C11, temp1, temp2);
    sum(C12, temp3, temp4);
    sum(C21, temp5, temp6);
    sum(C22, temp7, temp8);


    //合并
    merge(matrix_ans, C11, C12, C21, C22);
}

void gemm(vector<vector<int> >&matrix_ans, vector<vector<int> >matrixA,vector<vector<int> > matrixB){
    int n = matrix_ans.size();
    for(int i = 0; i < n; i++){
        for(int j = 0; j < n; j++){
            for(int a = 0; a < n; a++){
                matrix_ans[i][j] += matrixA[i][a] * matrixB[a][j];
            }
        }
    }
}
