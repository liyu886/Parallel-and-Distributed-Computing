#include<iostream>
#include<stdlib.h>
#include<time.h>
#include<vector>
#include<fstream>
#include"timer.h"

#define range 100
#define flag 64
using namespace std;

void print(vector<vector<int> > n);

//分解
void separate(vector<vector <int> >matrix, vector<vector <int> >& A11, vector<vector <int> >&A12, vector<vector <int> >&A21, vector<vector <int> >&A22);

//create matrix_S
//矩阵减法
//矩阵加法
void sum(vector<vector <int> >&sum, vector<vector <int> > a, vector<vector <int> >b);
void reduce(vector<vector <int> >&reduce, vector<vector <int> > a, vector<vector <int> >b);
void strassen (vector<vector <int> >&producer, vector<vector <int> > a, vector<vector <int> >b);

int main(){
    int n = 512;
    double start, finish;
    ofstream fp;
    fp.open("result.txt");



    int seed = time(0);
    srand(seed);

    vector<vector<int> > matrixA(n, vector<int>(n, 0));
    vector<vector<int> > matrixB(n, vector<int>(n, 0));
    vector<vector<int> > matrix_ans(n, vector<int>(n, 0));

    
    for(int i = 0; i < n; i++){
        for(int j = 0; j < n; j++){
            matrixA[i][j] = rand() % range;
            matrixB[i][j] = rand() % range;
        }
    }


    //cout << "random " << n << "*" << n << " matrix " << endl;
    fp << "random " << n << "*" << n << " matrix " << endl;

    for(int i = 0; i < n; i++){
        for(int j = 0; j < n; j++){
            //cout << matrixA[i][j] << " ";
            fp << matrixA[i][j] << " ";
        }
        //cout << endl;
        fp << endl;
    }
    
    //cout << "random " << n << "*" << n << " matrix " << endl;
    fp << "random " << n << "*" << n << " matrix " << endl;

    for(int i = 0; i < n; i++){
        for(int j = 0; j < n; j++){
            //cout << matrixB[i][j] << " ";
            fp << matrixB[i][j] << " ";
        }
        //cout << endl;
        fp << endl;
    }

    GET_TIME(start);

    strassen(matrix_ans, matrixA, matrixB);

    GET_TIME(finish);
    fp << "result1" << endl;

    for(int i = 0; i < n; i++){
        for(int j = 0; j < n; j++){
            //cout << matrix_ans[i][j] << " ";
            fp << matrix_ans[i][j] << " ";
        }
        //cout << endl;
        fp << endl;
    }

    cout << "strassen:" << endl;
    cout << n << " * " << n << " matrixA times " << n << " * " << n << " matrixB " << endl;
    cout << "Runtime is " << finish - start << endl;

    fp.close();
    

    //cout << "result" << endl;
   
    

}


void separate(vector<vector <int> >matrix, vector<vector <int> >& A11, vector<vector <int> >&A12, vector<vector <int> >&A21, vector<vector <int> >&A22){
    vector<int> temp1, temp2, temp3, temp4;
    int size = matrix.size();
    for(int i = 0; i < size/2; i++){
        temp1.assign(matrix[i].begin(), matrix[i].begin() + size/2);
        A11.push_back(temp1);

        temp2.assign(matrix[i].begin() + size/2, matrix[i].end());
        A12.push_back(temp2);

        temp3.assign(matrix[size/2 + i].begin(), matrix[size/2 + i].begin() + size/2);
        A21.push_back(temp3);

        temp4.assign(matrix[size/2 + i].begin() + size/2, matrix[size/2 + i].end());
        A22.push_back(temp4);
    }
    
}

void sum(vector<vector <int> >&sum, vector<vector <int> > a, vector<vector <int> >b){
    for(int i = 0; i < a.size(); i++){
        for(int j = 0; j < a[i].size(); j++){
            sum[i][j] = a[i][j] + b[i][j];
        }
    }
}
void reduce(vector<vector <int> >&reduce, vector<vector <int> > a, vector<vector <int> >b){
    for(int i = 0; i < a.size(); i++){
        for(int j = 0; j < a[i].size(); j++){
            reduce[i][j] = a[i][j] - b[i][j];
        }
    }
}

void strassen (vector<vector <int> >&producer, vector<vector <int> > a, vector<vector <int> >b){
    
    if(a.size() <= flag){
        int n = a.size();
        for(int i = 0; i < n; i++){
            for(int j = 0; j < n; j++){
                for(int k = 0; k < n; k++){
                    producer[i][j] += a[i][k] * b[k][j];
                }
            }
        }
        
    }else{
        vector<vector<int> > A11;
        vector<vector<int> > A12;
        vector<vector<int> > A21;
        vector<vector<int> > A22;
        vector<vector<int> > B11;
        vector<vector<int> > B12;
        vector<vector<int> > B21;
        vector<vector<int> > B22;

        separate(a, A11, A12, A21, A22);
        separate(b, B11, B12, B21, B22);

        int size = A11.size();

        vector<vector<int> >S1(size, vector<int>(size, 0));
        vector<vector<int> >S2(size, vector<int>(size, 0));
        vector<vector<int> >S3(size, vector<int>(size, 0));
        vector<vector<int> >S4(size, vector<int>(size, 0));
        vector<vector<int> >S5(size, vector<int>(size, 0));
        vector<vector<int> >S6(size, vector<int>(size, 0));
        vector<vector<int> >S7(size, vector<int>(size, 0));
        vector<vector<int> >S8(size, vector<int>(size, 0));
        vector<vector<int> >S9(size, vector<int>(size, 0));
        vector<vector<int> >S10(size, vector<int>(size, 0));

        reduce(S1, B12, B22);
        
        sum(S2, A11, A12);
        sum(S3, A21, A22);
        reduce(S4, B21, B11);
        sum(S5, A11, A22);
        sum(S6, B11, B22);
        reduce(S7, A12, A22);
        sum(S8, B21, B22);
        reduce(S9, A11, A21);
        sum(S10, B11, B12);

        vector<vector<int> >P1(size, vector<int>(size, 0));
        vector<vector<int> >P2(size, vector<int>(size, 0));
        vector<vector<int> >P3(size, vector<int>(size, 0));
        vector<vector<int> >P4(size, vector<int>(size, 0));
        vector<vector<int> >P5(size, vector<int>(size, 0));
        vector<vector<int> >P6(size, vector<int>(size, 0));
        vector<vector<int> >P7(size, vector<int>(size, 0));

        strassen(P1, A11, S1);
        strassen(P2, S2, B22);
        strassen(P3, S3, B11);
        strassen(P4, A22, S4);
        strassen(P5, S5, S6);
        strassen(P6, S7, S8);
        strassen(P7, S9, S10);

        
        vector<vector<int> >C11(size, vector<int>(size, 0));
        vector<vector<int> >C12(size, vector<int>(size, 0));
        vector<vector<int> >C21(size, vector<int>(size, 0));
        vector<vector<int> >C22(size, vector<int>(size, 0));

        sum(C11, P5, P4);
        
        reduce(C11, C11, P2);
        sum(C11, C11, P6);

        sum(C12, P1, P2);

        sum(C21, P3, P4);

        sum(C22, P5, P1);
        reduce(C22, C22, P3);
        reduce(C22, C22, P7);

        vector<int> temp(size, 0);
        vector<int> temp1(size, 0);
        for(int i = 0; i < C11.size(); i++){
            temp.assign(C11[i].begin(), C11[i].end());
            temp1.assign(C12[i].begin(), C12[i].end());
            temp1.insert(temp1.begin(), temp.begin(), temp.end());
            producer[i].assign(temp1.begin(), temp1.end());

            temp.assign(C21[i].begin(), C21[i].end());
            temp1.assign(C22[i].begin(), C22[i].end());
            temp1.insert(temp1.begin(), temp.begin(), temp.end());
            producer[C11.size() + i].assign(temp1.begin(), temp1.end());
        }
        

    }
}

void print(vector<vector<int> > n){
    for(int i = 0; i < n.size(); i++){
        for(int j = 0; j < n[i].size(); j++){
            cout << n[i][j] << " ";
        }
        cout << endl;
    }
}
