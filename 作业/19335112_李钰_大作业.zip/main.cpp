#include "unlocklist.h"
#include <omp.h>
#include "timer.h"

#define pushnum 20000
#define popnum 16000
int main(){
    //
    unlocklist myque;
    printf("shared queue has been created!\n");
    printf("start len: %d\n", myque.get_len());

    double start, end;

    GET_TIME(start);
    #pragma omp parallel for num_threads(5)
    for(int i = 0; i < pushnum; i++){
        myque.push_back(i);
        //printf("I'm %d thread, and push %d at the end of queue\n", omp_get_thread_num(), i);
    }
    GET_TIME(end);
    printf("push %d costs %lf s.\n", pushnum, end-start);
    printf("end len: %d\n", myque.get_len());

    GET_TIME(start);
    #pragma omp parallel for num_threads(4)
    for(int i = 0; i < popnum; i++){
        int temp = myque.get_pop();
        //printf("I'm %d thread, and pop %d at the front of queue\n", omp_get_thread_num(), i);
    }
    GET_TIME(end);

    printf("push %d costs %lf s.\n", popnum, end-start);
    printf("end len: %d\n", myque.get_len());

    return 0;
}