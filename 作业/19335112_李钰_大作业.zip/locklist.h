#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

using namespace std;

struct node{
    int value;
    node* next;
};


class locklist{
private:
    node* head;
    node* tail;
public:
    locklist();
    ~locklist();
    void push_back(int val);
    int get_pop();
    bool isempty();
    int get_len();
    int front();
};

//初始化函数：建一个初始值为0的节点，并且链表头尾均为该节点
locklist::locklist(){
    node* new_node = new node();
    new_node->value = 0;
    new_node->next = NULL;
    head = new_node;
    tail = new_node;
}

locklist::~locklist(){
    int len = get_len();

    while(len--){
        get_pop();
    }

    return;
}

void locklist::push_back(int val){
    node* new_node = new node();
    new_node->value = val;
    new_node->next = NULL;

    node *move = head;
    
    while(move->next != NULL){
        move = move->next;
    }
    move->next = new_node;
    tail = new_node;
    
}

int locklist::get_pop(){
    if(head->next != NULL){
        node* temp = head->next;
        head->next = temp->next;
        int res = temp->value;
        delete temp;
        return res;
    }else{
        return -1;
    }
    
}

bool locklist::isempty(){
    
    if(head->next == NULL){
        return true;
    }else{
        return false;
    }
}

int locklist::get_len(){
    if(head == tail){
        return -1;
    }

    int res = 1;
    node* move = head;
    while(move->next != NULL){
        move = move->next;
        res++;
    }

    return res;
}

int locklist::front(){
    if(head->next != NULL){
        return head->next->value;
    }else{
        return -1;
    }
}