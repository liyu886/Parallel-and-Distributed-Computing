#include <iostream>
#include <stdio.h>
#include <atomic>
#include <stdlib.h>
#include <unistd.h>

using namespace std;

struct node{
    int value;
    atomic<node*> next;
};


class unlocklist{
private:
    atomic<node*> head;
    atomic<node*> tail;
public:
    unlocklist();
    ~unlocklist();
    void push_back(int val);
    int get_pop();
    bool isempty();
    int get_len();
    int front();
};

//初始化函数：建一个初始值为0的节点，并且链表头尾均为该节点
unlocklist::unlocklist(){
    node* new_node = new node();
    new_node->value = 0;
    new_node->next = NULL;
    head = new_node;
    tail = new_node;
}

unlocklist::~unlocklist(){
    node* move = head.load();
    while(move != NULL){
        node* temp = move;
        move = move->next;
        delete temp;
    }
}

void unlocklist::push_back(int val){
    node* new_node = new node();
    new_node->value = val;
    new_node->next = NULL;

    node *tail_ptr , *tail_next_ptr;
    node* null_ptr = NULL;
    
    while(1){
        tail_ptr = tail;
        tail_next_ptr = tail.load()->next;

        if(tail_next_ptr != NULL){
            tail.compare_exchange_weak(tail_ptr, tail_next_ptr);
            //printf("push back failed\n");
            continue;
        }

        if(tail.load()->next.compare_exchange_weak(null_ptr, new_node)){
            tail.compare_exchange_weak(tail_ptr, new_node);
            //printf("push back successfully\n");
            return;
        }
    }
}

int unlocklist::get_pop(){
    node* head_ptr, *tail_ptr, *head_next_ptr;
    while(1){
        head_ptr = head;
        tail_ptr = tail;
        head_next_ptr = head_ptr->next;

        //链表为空
        if(head_next_ptr == NULL){
            printf("it is empty!\n");
            return -1;
        }

        if(head_ptr == tail_ptr){
            printf("need update\n");
            tail.compare_exchange_weak(tail_ptr, head_next_ptr);
            continue;
        }

        if(head.compare_exchange_weak(head_ptr, head_next_ptr)){
            int val = head_ptr->value;
            delete head_ptr;
            //printf("pop successfuly\n");
            return val;
        }
    }
}


bool unlocklist::isempty(){
    node* head_ptr = head;
    if(head_ptr->next == NULL){
        return true;
    }else{
        return false;
    }
}

int unlocklist::get_len(){
    if(head.load() == tail.load()){
        return 1;
    }

    int res = 1;
    node* move = head;
    while(move->next.load()){
        move = move->next;
        res++;
    }

    return res;
}

int unlocklist::front(){
    if(head != tail){
        node* res = head.load()->next;
        return res->value;
    }else{
        return -1;
    }
}