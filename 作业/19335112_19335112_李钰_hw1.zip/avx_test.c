#include <immintrin.h>
#include <stdio.h>
#include <time.h>

/* 向量长度 */
#define VEC_LEN (8) 

float a[] = {10, 20, 30, 40, 50, 60, 70, 80};
float b[] = {0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5};
float c[] = {0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5};
 
 void multiplication();
 
int main(int argc, char* argv[]){

    printf("=================Arithmetic==================\n");
    printf("\n");
    printf("Float Addition:\n");

    __m256 first  = _mm256_loadu_ps (a);       //后缀是ps 单精度
    __m256 second = _mm256_loadu_ps (b);
    __m256 result1 = _mm256_add_ps (first, second);
                    _mm256_storeu_ps (c, result1);
                        
    for (int i = 0;i < 8; i++)
    {
        printf("%f\n", c[i]);
    }

    printf("\n\n");

    
    printf("Integer Addition:\n");
    __m256i int1 = _mm256_set_epi64x(10, 20, 30, 40);
    __m256i int2 = _mm256_set_epi64x(5, 5, 5, 5);
    __m256i result2 = _mm256_add_epi64(int1, int2);

    long int* values = (long int*) &result2;
    for(int i = 0; i < 4; i++){
        printf("%ld ", values[i]);
    }

    printf("\n\n");

    printf("Double Addition:\n");
    __m256d x = _mm256_set_pd(1.0, 2.0,3.0,4.0);
    __m256d y = _mm256_set_pd(5.1, 5.2, 5.3, 5.4);
    __m256d result3 = _mm256_add_pd(x, y);

    double* values1 = (double*) &result3;
    for(int i = 0; i < 4; i++){
        printf("%lf ", values1[i]);
    }


    printf("\n\n");
    

    

    return 0;
}


