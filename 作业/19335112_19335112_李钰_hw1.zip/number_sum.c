/* File:     hw3_pthread.c
 *
 * Purpose:  sum of n integers
 *
 * Compile:  gcc -g -Wall -o number_sum number_sum.c -lm -lpthread
 *
 *
 * Run:      ./number_sum <number of threads> <n>
 *           n is the number of terms of the Maclaurin series to use
 *           n should be evenly divisible by the number of threads
 *
 * Input:    none
 * Output:   The estimate of pi using multiple threads, one thread, and the
 *           value computed by the math library arctan function
 *           Also elapsed times for the multithreaded and singlethreaded
 *           computations.
 *
 * Notes:
 *    1.  The radius of convergence for the series is only 1.  So the
 *        series converges quite slowly.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <pthread.h>
#include <semaphore.h>
#include <sys/time.h>
#include <time.h>
#include "timer.h"

const int MAX_THREADS = 1024;

long thread_count;
long long n;
long long sum;

sem_t sem;
int* arr;

void* Thread_sum(void* rank);

/* Only executed by main thread */
void Get_args(int argc, char* argv[]);
void Usage(char* prog_name);

int main(int argc, char* argv[]) {
    long       thread;  /* Use long in case of a 64-bit system */
    pthread_t* thread_handles;
    int seed = time(0);
    srand(seed);
    double start, end;

    Get_args(argc, argv);

    thread_handles = (pthread_t*) malloc (thread_count*sizeof(pthread_t));//为线程分配内存空间 
    sem_init(&sem, 0, 1);//初始化信号量 为1，现在可以让一个线程进入临界区 
    sum = 0.0;//初始化最后的和 

    arr = (int*)malloc(sizeof(int) * n);

    for(int i = 0; i < n; i++){         //随即生成m大小的数组
        arr[i] = rand() % 100;
    }

    GET_TIME(start);
    for (thread = 0; thread < thread_count; thread++)//创建create_count个线程 ，运行Thread_sum函数 
        pthread_create(&thread_handles[thread], NULL,
            Thread_sum, (void*)thread);

    for (thread = 0; thread < thread_count; thread++)
        pthread_join(thread_handles[thread], NULL);//加入线程 
    GET_TIME(end);

    printf("\n");
    printf("parallel\n");
    printf("the sum is %lld.\n", sum);
    printf("cost time:%lf\n", end - start);

    GET_TIME(start);
    int sum1 = 0;
    for(int i = 0; i < n; i++){
        sum1 += arr[i];
    }
    GET_TIME(end);
    
    printf("\n\n");
    printf("serial\n");
    printf("the sum is %lld.\n", sum1);
    printf("cost time:%lf\n", end - start);
    sem_destroy(&sem);//销毁信号量 
    free(thread_handles);//释放线程占用的空间 
    free(arr);
    return 0;
}  /* main */

/*------------------------------------------------------------------*/
void* Thread_sum(void* rank) {
    long my_rank = (long) rank;
    long long my_sum = 0;

    long long i;
    long long my_n = n / thread_count;
    long long my_first_i = my_n * my_rank;
    long long my_last_i = my_first_i + my_n;

    for( i = my_first_i; i < my_last_i; i++){
        my_sum += arr[i];
    }

    sem_wait(&sem);
    sum += my_sum;
    sem_post(&sem);

    return NULL;
}  /* Thread_sum */

/*------------------------------------------------------------------
 * Function:    Get_args
 * Purpose:     Get the command line args
 * In args:     argc, argv
 * Globals out: thread_count, n
 */
void Get_args(int argc, char* argv[]) {
   if (argc != 3) Usage(argv[0]);
   thread_count = strtol(argv[1], NULL, 10);
   if (thread_count <= 0 || thread_count > MAX_THREADS) Usage(argv[0]);
   n = strtoll(argv[2], NULL, 10);
   if (n <= 0) Usage(argv[0]);
}  /* Get_args */


/*------------------------------------------------------------------
 * Function:  Usage
 * Purpose:   Print a message explaining how to run the program
 * In arg:    prog_name
 */
void Usage(char* prog_name) {
   fprintf(stderr, "usage: %s <number of threads> <n>\n", prog_name);
   fprintf(stderr, "   n is the number of terms and should be >= 1\n");
   fprintf(stderr, "   n should be evenly divisible by the number of threads\n");
   exit(0);
}  /* Usage */