#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include <unistd.h>
#include "timer.h"
#define n 160
#define block 1
#define sleep_time 8
#define thread_count 4

void dummy_static(){
    #pragma omp parallel for num_threads(thread_count) schedule(static, block)
    for(int i = 0; i < n; i++){
        sleep(sleep_time);
    }
}

void dummy_dynamic(){
    #pragma omp parallel for num_threads(thread_count) schedule(dynamic, block)
    for(int i = 0; i < n; i++){
        sleep(sleep_time);
    }
}

void dummy_guided(){
    #pragma omp parallel for num_threads(thread_count) schedule(guided, block)
    for(int i = 0; i < n; i++){
        sleep(sleep_time);
    }
}

int main(){

    double start, end;

    GET_TIME(start);
    dummy_static();
    GET_TIME(end);

    printf("%d threads run codes by static way and %d block takes %lf s.\n", thread_count, block, end - start);

    GET_TIME(start);
    dummy_dynamic();
    GET_TIME(end);

    printf("%d threads run codes by dynamic way and %d block takes %lf s.\n", thread_count, block, end - start);

    GET_TIME(start);
    dummy_guided();
    GET_TIME(end);

    printf("%d threads run codes by guided way and %d block takes %lf s.\n", thread_count, block, end - start);
}
