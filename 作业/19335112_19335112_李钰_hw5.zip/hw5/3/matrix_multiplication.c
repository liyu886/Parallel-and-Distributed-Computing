#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include<string.h>
#include "timer.h"

int thread_count;
int row_size, col_size, element_num;
int* row_info;
int* col_info;
double* element_val;
double* vector;
double* res;

void init_matrix(FILE* fp);
void init_vector();
double parallel_multiplication();



int main(int arg, char* argc[]){

    thread_count = strtol(argc[1], NULL, 10);
    FILE* fp = fopen(argc[2], "r");
    if(!fp){
        printf("Open file error!\n");
    }

    srand(331.0);
    char str[100];
    int temp;

    fgets(str, 100, fp);
    fgets(str, 100, fp);
    
    fscanf(fp, "%s %d %d %d %d\n", str, &row_size, &col_size, &element_num, &temp);

    fgets(str, 100, fp);
    
    init_matrix(fp);
   
    fclose(fp);

    init_vector();

    double cost_time1 = parallel_multiplication();
    printf("Run by %d threads, cost time is %lf s.\n", thread_count, cost_time1);

    double cost_time2 = 0.000044;

    printf("Speedup is %lf\n", cost_time2 / cost_time1);
    printf("Efficient is %lf \n", cost_time2 / (thread_count*cost_time1));

    FILE* fp1 = fopen(argc[3], "w");
    fprintf(fp1, "%d %d %d\n\n", row_size, col_size, element_num);
    
    for(int i = 0; i < col_size; i++){
        fprintf(fp1, "%lf ", vector[i]);
    }
    char c = '\n';
    fprintf(fp1, "%c\n", c);

    for(int i = 0; i < row_size; i++){
        fprintf(fp1, "%lf ", res[i]);
    }
    fclose(fp1);
    
    free(row_info);
    free(col_info);
    free(element_val);
    free(vector);
    free(res);

    
    
}

void init_matrix(FILE* fp){
    row_info = (int* )malloc(sizeof(int) * row_size);
    element_val = (double* )malloc(sizeof(double) * element_num);
    col_info = (int* )malloc(sizeof(int) * element_num);

    for(int i = 0; i < row_size; i++){
        fscanf(fp, "%d", &row_info[i]);
        row_info[i]--;
    }
    for(int i = 0; i < element_num; i++){
        fscanf(fp, "%d", &col_info[i]);
        col_info[i]--;
    }
    for(int i = 0; i < element_num; i++){
        fscanf(fp, "%lf", &element_val[i]);
    }

    return;
}

void init_vector(){
    vector = (double* )malloc(sizeof(double) * col_size);
    for(int i = 0; i < col_size; i++){
        vector[i] = (double)(rand() % 1000) / 100.0;
    }
}

double parallel_multiplication(){
    double start, end; 
    res = (double* )malloc(sizeof(double) * row_size);
    memset(res, 0, row_size * sizeof(double));

    GET_TIME(start);
    #pragma omp parallel for num_threads(thread_count)
    for(int i = 0; i < row_size; i++){
        int col_begin = row_info[i];//
        int col_end = (i == row_size - 1) ? element_num - 1 : (row_info[i + 1] - 1);

        for(int j = col_begin; j <= col_end; j++){
            res[i] += vector[col_info[j]] * element_val[j];
        }
    }   
    GET_TIME(end);  
    return end - start;
}



