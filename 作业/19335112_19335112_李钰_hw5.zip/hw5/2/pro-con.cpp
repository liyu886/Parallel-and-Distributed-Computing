#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <queue>
#include <omp.h>

using namespace std;

int thread_num;
int max_size = 5;
omp_lock_t mymutex;

void producer();
void consumer();

queue<char> myque;

int main(int arg, char* argc[]){
    thread_num = strtol(argc[1], NULL, 10);
    int cases = 4;
    
    omp_init_lock(&mymutex);
    srand(123);
    int n = 5;

    for(int i = 0; i < cases; i++){
        #pragma omp parallel sections
        {
            #pragma omp section
            {
                producer();
                
            }
            #pragma omp section
            {
                producer();
                
            }
            

            #pragma omp section
            {
                consumer();
            }

            #pragma omp section
            {
                consumer();
            }

        }

        int size = myque.size();
        if(size == 0){
            printf("The %d cycle is over,the queue is empty.\n", i+1);
        }else{
            printf("The %d cycle is over, the remaining letters in the queue are ", i+1);
            while(size--){
                char temp = myque.front();
                printf("%c ", temp);
                myque.pop();
                myque.push(temp);
            }
            printf("\n");
        }
        printf("\n");
    }

    omp_destroy_lock(&mymutex);
     
    return 0; 
}


void producer(){
    char temp = rand() % 26 + 'A';

    omp_set_lock(&mymutex);
    if(myque.size() != max_size){
        myque.push(temp);
        printf("Thread %d adds message %c to queue successfully.\n", omp_get_thread_num(), temp);
    }else{
        printf("The queue is full, thread %d adds message failed.\n", omp_get_thread_num());
    }
    omp_unset_lock(&mymutex);

}


void consumer(){
    omp_set_lock(&mymutex);
    if(myque.size() != 0){
        char temp = myque.front();
        myque.pop();
        printf("Thread %d takes message %c from queue successfully.\n", omp_get_thread_num(), temp);
    }else{
        printf("The queue is empty, thread %d takes message failed.\n", omp_get_thread_num());
    }
    omp_unset_lock(&mymutex);
}

