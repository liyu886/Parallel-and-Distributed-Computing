#include<pthread.h>
#include<stdio.h>
#include<stdlib.h>

#define thread_count 2
int global = 0;
pthread_mutex_t mymutex;

void* thread_fun(void* rank);
int main(){
    long thread;
    pthread_t* thread_handles;
    pthread_mutex_init(&mymutex, NULL);

    thread_handles = (pthread_t*) malloc (thread_count*sizeof(pthread_t));

    for(thread = 0; thread < thread_count; thread++){
        pthread_create(&thread_handles[thread], NULL, thread_fun, (void*)thread);
    }

    for(thread = 0; thread < thread_count; thread++){
        pthread_join(thread_handles[thread], NULL);
    }
    printf("global is:%d.\n", global);
    free(thread_handles);
    pthread_mutex_destroy(&mymutex);
}

void* thread_fun(void* rank){
    for(int i = 0; i < 10; i++){
        pthread_mutex_lock(&mymutex);
        global++;
        pthread_mutex_unlock(&mymutex);
    }
    return NULL;
}