/* */
#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

#define SIZE 16

int cmp(const void*_a, const void*_b){
    int* a = (int*)_a;    //强制类型转换
    int* b = (int*)_b;
    return *a - *b;
}

int main(int argc, char* argv[]){

    int comm_sz, my_rank;
    int local_n;
    int partner;
    int* array;
    int* local_array;

    MPI_Status Stat;

    MPI_Init(&argc, &argv);
    MPI_Comm_size(MPI_COMM_WORLD, &comm_sz);
    MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);

    local_n = SIZE / comm_sz;
    local_array = (int* )malloc(sizeof(int) * local_n * 2);
    //temp = (int* )malloc(sizeof(int) * local_n);

    if(my_rank == 0){
        array = (int* )malloc(sizeof(int) * SIZE);
        printf("Initial array:\n");
        //give values
        for(int i = 0; i < SIZE; i++){
            array[i] = rand() % 100;
            printf("%d ", array[i]);
        }
        printf("\n");
    }
    MPI_Scatter(array, local_n, MPI_INT, local_array, local_n, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Barrier(MPI_COMM_WORLD);
    
    // for(int i = 0; i < comm_sz; i++){
    //     if(my_rank == i){
    //         for(int j = 0; j < local_n; j++){
    //             printf("%d ", local_array[j]);
    //         }
    //         printf("\n");
    //     }
    // }
    // MPI_Barrier(MPI_COMM_WORLD);
    for(int count = 0; count < comm_sz; count++){
        
        qsort(local_array, local_n, sizeof(int), cmp);
        if(count % 2 == 0){
            partner = (my_rank % 2 == 0) ? my_rank + 1 : my_rank - 1;       
        }else{
            partner = (my_rank % 2 == 0) ? my_rank - 1 : my_rank + 1; 
        }
        if(partner >= 0 && partner <= comm_sz - 1){
            if(my_rank % 2 == 0){
                MPI_Send(local_array, local_n, MPI_INT, partner, 1, MPI_COMM_WORLD);
                MPI_Recv(local_array + local_n, local_n, MPI_INT, partner, 1, MPI_COMM_WORLD, &Stat);
            }else{
                MPI_Recv(local_array + local_n, local_n, MPI_INT, partner, 1, MPI_COMM_WORLD, &Stat);
                MPI_Send(local_array, local_n, MPI_INT, partner, 1, MPI_COMM_WORLD);
            }
            qsort(local_array, 2*local_n, sizeof(int), cmp);
            if(partner < my_rank){
                for(int i = 0; i < local_n; i++){
                    local_array[i] = local_array[local_n + i];
                }
            }
        }
        // MPI_Barrier(MPI_COMM_WORLD);
        // if(my_rank == 0)
        //     printf("in %d turn:\n", count);
        // for(int i = 0; i < comm_sz; i++){
        //     if(my_rank == i){
        //         for(int j = 0; j < local_n; j++){
        //             printf("%d ", local_array[j]);
        //         }
        //         printf("\n");
        //     }
        // }
        MPI_Barrier(MPI_COMM_WORLD);
    }

    MPI_Gather(local_array, local_n, MPI_INT, array, local_n, MPI_INT, 0, MPI_COMM_WORLD);
    if(my_rank == 0){
        printf("Final array:\n");
        for(int i = 0; i < SIZE; i++){
            printf("%d ", array[i]);
        }
        printf("\n");
    }
    MPI_Finalize();

}