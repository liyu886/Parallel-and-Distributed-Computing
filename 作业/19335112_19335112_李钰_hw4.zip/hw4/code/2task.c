   /******************************************
 * Compile:
 * gcc -g -o 2task 2task.c -lpthread
 * Run:       
 * ./2task <number of threads>
 ******************************************/
#define _GNU_SOURCE
#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<unistd.h>
#include<sys/syscall.h>
#include<sys/sysinfo.h>
#include<sys/types.h>
#include"timer.h"
#include<sched.h>


#define range 5
//global var
int m = 1000;
int n = 1000;
int k = 1;
int *matrixA, *matrixB, *matrixC;
int *res;
int thread_count;//线程个数
int cores_num;
int count = 0;

pthread_mutex_t mymutex;
pthread_cond_t mycond;

//functions
void print(int* matrix, int row, int col);
void initmatrix(int *A, int row, int col);
void* multiplication(void* rank);
void* sum(void* rank);

int main(int arg, char* argv[]){
    
    cores_num = sysconf(_SC_NPROCESSORS_CONF);
    cpu_set_t mask;
    CPU_ZERO(&mask);
    CPU_SET(0,&mask);
    sched_setaffinity(0, sizeof(cpu_set_t), &mask) ;
    /*
    printf("pid is %d.\n", getpid());
    long abc = 2000000000;
    while(abc--){
        long temp = abc * abc ;
    }
    */
    matrixA = (int*)malloc(m * n * sizeof(int));
    matrixB = (int*)malloc(n * k * sizeof(int));
    matrixC = (int*)malloc(m * n * sizeof(int));
    res = (int*)malloc(m * k * sizeof(int));

    pthread_mutex_init(&mymutex, NULL);
    pthread_cond_init(&mycond, NULL);
    initmatrix(matrixA, m,n);
    initmatrix(matrixB, n, k);

    double start, finish;

    GET_TIME(start);

    long thread;
    pthread_t *thread_handles;
    thread_count = strtol(argv[1], NULL, 10);
    thread_handles = malloc(thread_count * sizeof(pthread_t));

    for(thread = 0; thread < thread_count - 1; thread++){
        pthread_create(&thread_handles[thread], NULL, multiplication, (void*)thread);
    }

    pthread_create(&thread_handles[thread], NULL, sum, (void*)thread);
    
    pthread_mutex_lock(&mymutex);
    count++;
    pthread_cond_signal(&mycond);
    pthread_mutex_unlock(&mymutex);


    for(thread = 0; thread < thread_count; thread++){
        pthread_join(thread_handles[thread], NULL);
    }

    free(thread_handles);
    pthread_mutex_destroy(&mymutex);
    pthread_cond_destroy(&mycond);
    GET_TIME(finish);
    /*
    printf("A:\n");
    print(matrixA, m, n);
    printf("B:\n");
    print(matrixB, n, k);
    printf("C:\n");
    print(matrixC, m, n);
    printf("res:\n");
    print(res, m, k);
    */
    printf("Run time is: %lfs\n", finish - start);
    

    free(matrixA);
    free(matrixB);
    free(matrixC);
    free(res);
    //printf("%d is over.\n", getpid());
}


void print(int* matrix, int row, int col){
    for(int i = 0; i < row; i++){
        for(int j = 0; j < col; j++){
            printf("%d ", matrix[i * col + j]);
        }
        printf("\n");
    }
}

void initmatrix(int *A, int row, int col){
    for(int i = 0 ; i < row * col; i++){
        A[i] = rand() % range;
    }
}

void* multiplication(void* rank){
    
    int my_rank = (long)rank;
    cpu_set_t mask;
    cpu_set_t get;
    CPU_ZERO(&mask);
    CPU_SET((my_rank+1)%cores_num,&mask);

    if (sched_setaffinity(0, sizeof(mask), &mask) == -1)//设置线程CPU亲和力
    {
        printf("warning: could not set CPU affinity \n");
    }

    CPU_ZERO(&get);
    if (sched_getaffinity(0, sizeof(get), &get) == -1)//获取线程CPU亲和力
    {
         printf("warning: cound not get thread affinity, continuing...\n");
    }
    /* 
    printf("this is %ld.\n", syscall(SYS_gettid));
   
    long abc = 2000000000;
    while(abc--){
        long temp = abc * abc ;
    }
    */
    
    int quotient = m / thread_count;
    int remainder = m % thread_count;
    int my_first_row, my_last_row;//本线程要计算的起始行和结束行
    int my_local_n;//本线程要计算的行数

    //如果不能平均分配（有余数）
    //对于rank小于剩余行数的线程来说，就多计算一行
    if(my_rank < remainder){
        my_local_n = quotient + 1;
        my_first_row = my_rank * my_local_n;
        my_last_row = my_first_row + my_local_n;
    }else{
        my_local_n = quotient;
        my_first_row = my_rank * my_local_n + remainder;
        my_last_row = my_first_row + my_local_n;
    }

    for(int i = my_first_row; i < my_last_row; i++){
        for(int j = 0; j < n; j++){
            matrixC[i * n + j] = matrixA[i * n + j] * matrixB[j];
        }
    }
    pthread_mutex_lock(&mymutex);
    count++;
    pthread_cond_signal(&mycond);
    pthread_mutex_unlock(&mymutex);
    //printf("%ld is over!\n", syscall(SYS_gettid));
    return NULL;

}

void* sum(void* rank){
    
    pthread_mutex_lock(&mymutex);
    while(count < thread_count){
        pthread_cond_wait(&mycond, &mymutex);
    }
    int my_rank = (long)rank;
    cpu_set_t mask;
    cpu_set_t get;
    CPU_ZERO(&mask);
    CPU_SET(0, &mask);

    if (sched_setaffinity(0, sizeof(mask), &mask) == -1)//设置线程CPU亲和力
    {
        printf("warning: could not set CPU affinity \n");
    }

    CPU_ZERO(&get);
    if (sched_getaffinity(0, sizeof(get), &get) == -1)//获取线程CPU亲和力
    {
         printf("warning: cound not get thread affinity, continuing...\n");
    }
    /*
    printf("this is %ld.\n", syscall(SYS_gettid));
    
    long abc = 2000000000;
    while(abc--){
        long temp = abc * abc ;
    }
    */
    for(int i = 0; i < m; i++){
        int temp = 0;
        for(int j = 0; j < n; j++){
            temp += matrixC[i * n + j];
        }
        res[i] = temp;
    }
    pthread_cond_signal(&mycond);
    pthread_mutex_unlock(&mymutex);
    //printf("%ld is over!\n", syscall(SYS_gettid));
    return NULL;
}