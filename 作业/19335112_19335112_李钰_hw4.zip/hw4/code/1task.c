   /******************************************
 * Compile:
 * gcc -g -o 1task 1task.c -lpthread
 * Run:       
 * ./1task <number of threads>
 ******************************************/
#define _GNU_SOURCE
#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<unistd.h>
#include<sys/syscall.h>
#include<sys/sysinfo.h>
#include<sys/types.h>
#include"timer.h"
#include<sched.h>


#define range 5
//global var
int m = 1000;
int n = 1000;
int k = 1;
int *matrixA, *matrixB, *matrixC;
int thread_count;//线程个数
int cores_num;

//functions
void print(int* matrix, int row, int col);
void initmatrix(int *A, int row, int col);
void* gemm(void* rank);

int main(int arg, char* argv[]){
    /*
    cores_num = sysconf(_SC_NPROCESSORS_CONF);
    cpu_set_t mask;
    CPU_ZERO(&mask);
    CPU_SET(0,&mask);
    sched_setaffinity(0, sizeof(cpu_set_t), &mask) ;
    
    printf("pid is %d.\n", getpid());
    long abc = 2000000000;
    while(abc--){
        long temp = abc * abc ;
    }
    */
    matrixA = (int*)malloc(m * n * sizeof(int));
    matrixB = (int*)malloc(n * k * sizeof(int));
    matrixC = (int*)malloc(m * k * sizeof(int));

    initmatrix(matrixA, m,n);
    initmatrix(matrixB, n, k);

    double start, finish;

    GET_TIME(start);

    long thread;
    pthread_t *thread_handles;
    thread_count = strtol(argv[1], NULL, 10);
    thread_handles = malloc(thread_count * sizeof(pthread_t));

    for(thread = 0; thread < thread_count; thread++){
        pthread_create(&thread_handles[thread], NULL, gemm, (void*)thread);
    }

    


    for(thread = 0; thread < thread_count; thread++){
        pthread_join(thread_handles[thread], NULL);
    }

    free(thread_handles);

    GET_TIME(finish);

    printf("Run time is: %lfs\n", finish - start);
    

    free(matrixA);
    free(matrixB);
    free(matrixC);
    //printf("%d is over.\n", getpid());
}


void print(int* matrix, int row, int col){
    for(int i = 0; i < row; i++){
        for(int j = 0; j < col; j++){
            printf("%d ", matrix[i * col + j]);
        }
        printf("\n");
    }
}

void initmatrix(int *A, int row, int col){
    for(int i = 0 ; i < row * col; i++){
        A[i] = rand() % range;
    }
}

void* gemm(void* rank){
    
    int my_rank = (long)rank;
    /*
    cpu_set_t mask;
    cpu_set_t get;
    CPU_ZERO(&mask);
    CPU_SET((my_rank+1)%cores_num,&mask);

    if (sched_setaffinity(0, sizeof(mask), &mask) == -1)//设置线程CPU亲和力
    {
        printf("warning: could not set CPU affinity \n");
    }

    CPU_ZERO(&get);
    if (sched_getaffinity(0, sizeof(get), &get) == -1)//获取线程CPU亲和力
    {
         printf("warning: cound not get thread affinity, continuing...\n");
    }
    
    printf("this is %ld.\n", syscall(SYS_gettid));
    
    long abc = 2000000000;
    while(abc--){
        long temp = abc * abc ;
    }
    */
    
    int quotient = m / thread_count;
    int remainder = m % thread_count;
    int my_first_row, my_last_row;//本线程要计算的起始行和结束行
    int my_local_n;//本线程要计算的行数

    //如果不能平均分配（有余数）
    //对于rank小于剩余行数的线程来说，就多计算一行
    if(my_rank < remainder){
        my_local_n = quotient + 1;
        my_first_row = my_rank * my_local_n;
        my_last_row = my_first_row + my_local_n;
    }else{
        my_local_n = quotient;
        my_first_row = my_rank * my_local_n + remainder;
        my_last_row = my_first_row + my_local_n;
    }

    for(int i = my_first_row; i < my_last_row; i++){
        for(int j = 0; j < k; j++){
            int temp = 0;
            for(int a = 0; a < n; a++){
                temp += matrixA[i * n + a] * matrixB[a * k + j];
            }
            matrixC[i * k + j] = temp;
        }
    }
    //printf("%ld is over!\n", syscall(SYS_gettid));
    return NULL;

}